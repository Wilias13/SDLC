﻿using System;
using System.IO;
using System.IO.Compression;


namespace zadanie6
{
    class Program
    {
        static void Main(string[] args)
        {
            string sourceFile = "D://1.txt"; 
            string compressedFile = "D://1.gz"; 
            string targetFile = "D://1_rest.txt"; 

            Compress(sourceFile, compressedFile);
            Decompress(compressedFile, targetFile);

            
            Console.ReadLine();
        }

        public static void Compress(string sourceFile, string compressedFile)
        {
            using (FileStream sourceStream = new FileStream(sourceFile, FileMode.OpenOrCreate))
            {
                using (FileStream targetStream = File.Create(compressedFile))
                {
                    using (GZipStream compressionStream = new GZipStream(targetStream, CompressionMode.Compress))
                    {
                        sourceStream.CopyTo(compressionStream);
                        Console.WriteLine("Сжатие файла {0} завершено. Исходный размер: {1}  сжатый размер: {2}.",
                            sourceFile, sourceStream.Length.ToString(), targetStream.Length.ToString());
                    }
                }
            }
        }

        public static void Decompress(string compressedFile, string targetFile)
        {
            using (FileStream sourceStream = new FileStream(compressedFile, FileMode.OpenOrCreate))
            {
                using (FileStream targetStream = File.Create(targetFile))
                {
                    using (GZipStream decompressionStream = new GZipStream(sourceStream, CompressionMode.Decompress))
                    {
                        decompressionStream.CopyTo(targetStream);
                        Console.WriteLine("Восстановлен файл: {0}", targetFile);
                    }
                }
            }
        }
        public static void Delete(string sourceFile, string compressedFile, string targetFile)
        {
            FileInfo fileInf = new FileInfo(sourceFile);
            if (fileInf.Exists)
            {
                fileInf.Delete();
                Console.WriteLine("Файл удален");
            }
            fileInf = new FileInfo(compressedFile);
            if (fileInf.Exists)
            {
                fileInf.Delete();
                Console.WriteLine("Файл удален");
            }
            fileInf = new FileInfo(targetFile);
            if (fileInf.Exists)
            {
                fileInf.Delete();
                Console.WriteLine("Файл удален");
            }
        }
}
}
