﻿using System;
using System.IO;
using System.Xml;
using System.Xml.Linq;

namespace _07._09._2021_2_
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument xdoc = new XDocument();
            XElement man1 = new XElement("man");
            String name = Console.ReadLine();
            XAttribute man1NameAttr = new XAttribute("name", name);
            String surname = Console.ReadLine();
            XElement man1CompanyElem = new XElement("surname", surname);
            String age = Console.ReadLine();
            XElement man1PriceElem = new XElement("age", age);
            man1.Add(man1NameAttr);
            man1.Add(man1CompanyElem);
            man1.Add(man1PriceElem);



            XElement man2 = new XElement("man");
            name = Console.ReadLine();
            XAttribute man2NameAttr = new XAttribute("name", name);
            surname = Console.ReadLine();
            XElement man2CompanyElem = new XElement("surname", surname);
            age = Console.ReadLine();
            XElement man2PriceElem = new XElement("age", age);
            man2.Add(man2NameAttr);
            man2.Add(man2CompanyElem);
            man2.Add(man2PriceElem);


            XElement men = new XElement("men");
            men.Add(man1);
            men.Add(man2);
            xdoc.Add(men);
            xdoc.Save("D:\\men.xml");
            Read();
            Delete();
        }
        static void Read()
        {
            XDocument xdoc = XDocument.Load("D:\\men.xml");
            foreach (XElement phoneElement in xdoc.Element("men").Elements("man"))
            {
                XAttribute nameAttribute = phoneElement.Attribute("name");
                XElement surnameElement = phoneElement.Element("surname");
                XElement ageElement = phoneElement.Element("age");

                if (nameAttribute != null && surnameElement != null && ageElement != null)
                {
                    Console.WriteLine($"Имя: {nameAttribute.Value}");
                    Console.WriteLine($"Фамилия: {surnameElement.Value}");
                    Console.WriteLine($"Возраст: {ageElement.Value}");
                }
                Console.WriteLine();
            }
        }
        static void Delete()
        {
            FileInfo fi = new FileInfo("D:\\men.xml");
            if (fi.Exists)
            {
                fi.Delete();
                Console.WriteLine("Файл удален");
            }
                
        }
    }
}
